from cli import AlarmCLI
from alarm_manager import AlarmManager
from scheduler import AlarmScheduler


def main() -> None:
    manager = AlarmManager()
    scheduler = AlarmScheduler(manager)
    cli = AlarmCLI(manager, scheduler)

    cli.run()


if __name__ == "__main__":
    main()