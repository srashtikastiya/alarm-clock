import time
from datetime import datetime

from alarm_manager import AlarmManager
from models import Alarm


class AlarmScheduler:
    def __init__(self, manager: AlarmManager):
        self.manager = manager

    def run(self) -> None:
        print("Alarm clock started.")
        print("Press Ctrl+C to stop.\n")

        try:
            while True:
                now = datetime.now()

                current_time = now.strftime("%H:%M")
                current_date = now.date().isoformat()

                for alarm in self.manager.active_alarms():
                    if self._should_trigger(
                        alarm,
                        current_time,
                        current_date,
                    ):
                        self._trigger(alarm, current_date)

                time.sleep(0.5)

        except KeyboardInterrupt:
            print("\nAlarm clock stopped.")

    @staticmethod
    def _should_trigger(
        alarm: Alarm,
        current_time: str,
        current_date: str,
    ) -> bool:
        if not alarm.enabled:
            return False

        if alarm.time != current_time:
            return False

        # Prevent repeated triggering during the same minute.
        if alarm.last_triggered_date == current_date:
            return False

        return True

    @staticmethod
    def _trigger(
        alarm: Alarm,
        current_date: str,
    ) -> None:
        print()
        print("=" * 40)
        print("🔔 ALARM")
        print(f"ID:    {alarm.id}")
        print(f"Time:  {alarm.time}")
        print(f"Label: {alarm.label}")
        print("=" * 40)

        # Terminal bell
        print("\a", end="", flush=True)

        alarm.last_triggered_date = current_date

        # One-time alarms are disabled after firing.
        if not alarm.daily:
            alarm.enabled = False