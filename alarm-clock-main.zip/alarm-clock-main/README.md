# Alarm Clock CLI

A simple **Python CLI Alarm Clock** built as a Senior Software Engineer coding exercise.

## Features

* Create one-time alarms
* Create daily recurring alarms
* List all alarms
* Cancel alarms
* Multiple alarms support
* Terminal notification when alarm triggers
* Input validation and error handling
* Graceful `Ctrl+C` shutdown
* No database or external dependencies

## Tech Stack

* Python 3
* Python Standard Library
* In-memory storage

## Run

```bash
python app.py
```

## CLI Commands

```text
set HH:MM LABEL
set HH:MM LABEL --daily
list
cancel ALARM_ID
start
help
exit
```

### Example

```text
alarm> set 08:30 "Wake up"
Alarm 1 created: 08:30 (once) - Wake up

alarm> set 09:00 "Daily standup" --daily
Alarm 2 created: 09:00 (daily) - Daily standup

alarm> list

ID   TIME    REPEAT    STATUS    LABEL
------------------------------------------------------------
1    08:30   once      active    Wake up
2    09:00   daily     active    Daily standup

alarm> start
Alarm clock started.
Press Ctrl+C to stop.
```

## Design

```text
CLI
 │
 ▼
AlarmManager
 │
 ▼
Scheduler
 │
 ▼
System Clock
```

* `Alarm` — represents an alarm
* `AlarmManager` — create, list and cancel alarms
* `AlarmScheduler` — checks time and triggers alarms
* `AlarmCLI` — handles user commands

## Scheduling Approach

The scheduler uses a lightweight **500ms polling loop**.

This was intentionally chosen because:

* The exercise has a 30-minute time limit
* Minute-level alarm precision is sufficient
* It keeps the implementation simple and dependency-free

One-time alarms are disabled after triggering, while daily alarms remain active.

## Engineering Trade-offs

For this exercise, the focus was:

**Simple → Correct → Testable → Maintainable**

If the system needed to support thousands of alarms or second-level precision, the scheduler could be upgraded to a **priority queue (`heapq`)** and sleep until the next scheduled alarm.
