from dataclasses import dataclass
from typing import Optional


@dataclass
class Alarm:
    id: int
    time: str
    label: str
    daily: bool = False
    enabled: bool = True
    last_triggered_date: Optional[str] = None