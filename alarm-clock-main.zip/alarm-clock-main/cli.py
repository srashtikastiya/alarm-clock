import shlex

from alarm_manager import AlarmManager
from scheduler import AlarmScheduler


class AlarmCLI:
    def __init__(
        self,
        manager: AlarmManager,
        scheduler: AlarmScheduler,
    ):
        self.manager = manager
        self.scheduler = scheduler

    def run(self) -> None:
        self._print_welcome()

        while True:
            try:
                command = input("alarm> ").strip()

                if not command:
                    continue

                if command in {"exit", "quit"}:
                    print("Goodbye.")
                    return

                self._handle_command(command)

            except KeyboardInterrupt:
                print("\nGoodbye.")
                return

            except EOFError:
                print("\nGoodbye.")
                return

            except ValueError as exc:
                print(f"Error: {exc}")

    def _handle_command(self, command: str) -> None:
        parts = shlex.split(command)

        if not parts:
            return

        action = parts[0].lower()

        if action == "help":
            self._print_help()

        elif action == "set":
            self._set_alarm(parts[1:])

        elif action == "list":
            self._list_alarms()

        elif action == "cancel":
            self._cancel_alarm(parts[1:])

        elif action == "start":
            self.scheduler.run()

        else:
            print(
                f"Unknown command: '{action}'. "
                "Type 'help' for available commands."
            )

    def _set_alarm(self, args: list[str]) -> None:
        if len(args) < 2:
            raise ValueError(
                "Usage: set HH:MM LABEL [--daily]"
            )

        alarm_time = args[0]

        daily = "--daily" in args

        label_parts = [
            arg
            for arg in args[1:]
            if arg != "--daily"
        ]

        if not label_parts:
            raise ValueError("Alarm label cannot be empty.")

        label = " ".join(label_parts)

        alarm = self.manager.add(
            alarm_time=alarm_time,
            label=label,
            daily=daily,
        )

        repeat = "daily" if daily else "once"

        print(
            f"Alarm {alarm.id} created: "
            f"{alarm.time} ({repeat}) - {alarm.label}"
        )

    def _list_alarms(self) -> None:
        alarms = self.manager.list_alarms()

        if not alarms:
            print("No alarms configured.")
            return

        print()
        print(
            f"{'ID':<5}"
            f"{'TIME':<8}"
            f"{'REPEAT':<10}"
            f"{'STATUS':<10}"
            f"LABEL"
        )
        print("-" * 60)

        for alarm in alarms:
            repeat = "daily" if alarm.daily else "once"
            status = "active" if alarm.enabled else "disabled"

            print(
                f"{alarm.id:<5}"
                f"{alarm.time:<8}"
                f"{repeat:<10}"
                f"{status:<10}"
                f"{alarm.label}"
            )

        print()

    def _cancel_alarm(self, args: list[str]) -> None:
        if len(args) != 1:
            raise ValueError("Usage: cancel ALARM_ID")

        try:
            alarm_id = int(args[0])
        except ValueError as exc:
            raise ValueError(
                "Alarm ID must be an integer."
            ) from exc

        if not self.manager.cancel(alarm_id):
            print(f"Alarm {alarm_id} not found.")
            return

        print(f"Alarm {alarm_id} cancelled.")

    @staticmethod
    def _print_welcome() -> None:
        print("Alarm Clock")
        print("Type 'help' for available commands.\n")

    @staticmethod
    def _print_help() -> None:
        print(
            """
Commands:

  set HH:MM LABEL
      Create a one-time alarm.

  set HH:MM LABEL --daily
      Create a daily recurring alarm.

  list
      Show all alarms.

  cancel ALARM_ID
      Disable an alarm.

  start
      Start the alarm scheduler.

  help
      Show this help message.

  exit
      Exit the application.

Examples:

  set 08:30 "Wake up"
  set 09:00 "Daily standup" --daily
  list
  cancel 1
  start
"""
        )