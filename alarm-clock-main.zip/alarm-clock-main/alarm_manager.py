from datetime import datetime

from models import Alarm


TIME_FORMAT = "%H:%M"


class AlarmManager:
    def __init__(self):
        self._alarms: dict[int, Alarm] = {}
        self._next_id = 1

    def add(
        self,
        alarm_time: str,
        label: str,
        daily: bool = False,
    ) -> Alarm:
        self._validate_time(alarm_time)

        alarm = Alarm(
            id=self._next_id,
            time=alarm_time,
            label=label,
            daily=daily,
        )

        self._alarms[alarm.id] = alarm
        self._next_id += 1

        return alarm

    def cancel(self, alarm_id: int) -> bool:
        alarm = self._alarms.get(alarm_id)

        if alarm is None:
            return False

        alarm.enabled = False
        return True

    def list_alarms(self) -> list[Alarm]:
        return list(self._alarms.values())

    def active_alarms(self) -> list[Alarm]:
        return [
            alarm
            for alarm in self._alarms.values()
            if alarm.enabled
        ]

    @staticmethod
    def _validate_time(value: str) -> None:
        try:
            datetime.strptime(value, TIME_FORMAT)
        except ValueError as exc:
            raise ValueError(
                f"Invalid time '{value}'. Use HH:MM format."
            ) from exc